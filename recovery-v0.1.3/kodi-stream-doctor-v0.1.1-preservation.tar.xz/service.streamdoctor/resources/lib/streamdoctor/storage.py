import json, os, time
from typing import Dict, List

MAX_FILES_HARD = 20
MAX_TOTAL_BYTES = 20 * 1024 * 1024
MAX_FILE_BYTES = 4 * 1024 * 1024


def _safe_json_bytes(obj: Dict) -> bytes:
    raw = json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
    if len(raw) > MAX_FILE_BYTES:
        # Reports deliberately omit raw sample dumps; this should almost never trigger.
        slim = dict(obj)
        slim["storage_warning"] = "Report exceeded privacy size cap; nonessential detail omitted."
        slim.pop("samples", None)
        raw = json.dumps(slim, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError("report exceeds 4 MiB hard cap")
    return raw


def write_report(directory: str, report: Dict, max_files: int = 20) -> str:
    os.makedirs(directory, exist_ok=True)
    max_files = max(1, min(MAX_FILES_HARD, int(max_files or MAX_FILES_HARD)))
    raw = _safe_json_bytes(report)
    ns = time.time_ns()
    name = time.strftime("streamdoctor-%Y%m%d-%H%M%S", time.localtime(ns / 1_000_000_000)) + f"-{ns % 1_000_000_000:09d}.json"
    path = os.path.join(directory, name)
    # Some filesystems/platform clocks have coarse timestamp resolution. Never
    # overwrite a prior report if two stream sessions finish effectively at once.
    collision = 0
    while os.path.exists(path):
        collision += 1
        path = os.path.join(directory, name[:-5] + f"-{collision:02d}.json")
    temp = path + ".tmp"
    try:
        with open(temp, "wb") as f:
            f.write(raw)
            f.flush()
            try: os.fsync(f.fileno())
            except OSError: pass
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            try: os.remove(temp)
            except OSError: pass
    enforce_retention(directory, max_files)
    return path


def enforce_retention(directory: str, max_files: int = 20) -> None:
    max_files = max(1, min(MAX_FILES_HARD, int(max_files)))
    files: List[str] = []
    for n in os.listdir(directory):
        p = os.path.join(directory, n)
        if n.startswith("streamdoctor-") and n.endswith(".json") and os.path.isfile(p): files.append(p)
    files.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    total = 0
    for idx, p in enumerate(files):
        size = os.path.getsize(p)
        keep = idx < max_files and total + size <= MAX_TOTAL_BYTES and size <= MAX_FILE_BYTES
        if keep: total += size
        else:
            try: os.remove(p)
            except OSError: pass


def load_reports(directory: str, limit: int = 20):
    if not os.path.isdir(directory): return []
    files=[os.path.join(directory,n) for n in os.listdir(directory) if n.startswith("streamdoctor-") and n.endswith(".json")]
    files.sort(key=lambda p:os.path.getmtime(p), reverse=True)
    out=[]
    for p in files[:max(0,min(MAX_FILES_HARD,int(limit)))]:
        try:
            with open(p,encoding="utf-8") as f: out.append(json.load(f))
        except Exception:
            continue
    return out
